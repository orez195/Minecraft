$("#rules").click(function() {
	$("img").slideToggle("slow");
});